﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class danger : MonoBehaviour
{
    public bool h;
    public bool v;
    public float timer;
    public float speed;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Change", 0, timer);
    }

    // Update is called once per frame
    void Update()
    {
        if (h == true)
        {
            transform.position += new Vector3(speed, 0, 0)*Time.deltaTime;
        }
        if (v == true) 
        {

            transform.position += new Vector3(0, 0, speed) * Time.deltaTime;
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag=="Player")
        {
            SceneManager.LoadScene("GameLose");
        }
    }
    public void Change()
    {
        speed = -speed;
    }
}
